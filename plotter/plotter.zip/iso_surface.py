import os
import re
import numpy as np
import pyvista as pv
import matplotlib.pyplot as plt
# ------------------------
# CONFIGURATION
# ------------------------
script_dir = os.path.dirname(os.path.abspath(__file__))
vtk_file = os.path.join(script_dir, "box_3D_fine.vtk")
output_dir = script_dir
os.makedirs(output_dir, exist_ok=True)

# ------------------------
# LOAD & PARSE BEST SAMPLE
# ------------------------
mesh = pv.read(vtk_file)

ufol_keys = [k for k in mesh.point_data if re.match(r"U_FOL_\d+", k)]
ufe_keys = [k for k in mesh.point_data if re.match(r"U_FE_\d+", k)]
common_ids = sorted(set(k.split("_")[-1] for k in ufol_keys) & set(k.split("_")[-1] for k in ufe_keys))

min_error = float("inf")
best_id = None

for i in common_ids:
    u_fol = mesh[f"U_FOL_{i}"]
    u_fe = mesh[f"U_FE_{i}"]
    error = np.linalg.norm(np.linalg.norm(u_fol, axis=1) - np.linalg.norm(u_fe, axis=1))
    if error < min_error:
        min_error = error
        best_id = i

print(f" Best prediction index = {best_id} with L2 error = {min_error:.6f}")

# ------------------------
# FIELD NAMES
# ------------------------
U_FOL_field = f"U_FOL_{best_id}"
U_FE_field = f"U_FE_{best_id}"

# ------------------------
# COMPUTE MAGNITUDES FOR VISUALIZATION
# ------------------------
mesh.point_data["U_FOL_mag"] = np.linalg.norm(mesh[U_FOL_field], axis=1)
mesh.point_data["U_FE_mag"] = np.linalg.norm(mesh[U_FE_field], axis=1)

# ------------------------
# GENERATE CONTOURS AND SLICES
# ------------------------
fe_contour = mesh.contour(scalars="U_FE_mag", isosurfaces=5)
fol_contour = mesh.contour(scalars="U_FOL_mag", isosurfaces=5)

mesh.set_active_scalars("U_FE_mag")
fe_slices = mesh.slice_orthogonal()

mesh.set_active_scalars("U_FOL_mag")
fol_slices = mesh.slice_orthogonal()

# ------------------------
# PLOT 2x2 LAYOUT
# ------------------------
screenshot_path = os.path.join(output_dir, "fol_fem_contour_grid.png")

plotter = pv.Plotter(shape=(2, 2), window_size=(3200, 2400), off_screen=True)

# [subplot setup same as before]

plotter.subplot(0, 0)
plotter.add_text("FEM: Contour of U_FE_mag", font_size=12)
plotter.add_mesh(fe_contour, scalars="U_FE_mag", cmap="coolwarm")
plotter.add_axes()

plotter.subplot(0, 1)
plotter.add_text("FEM: Orthogonal Slices", font_size=12)
plotter.add_mesh(fe_slices, scalars="U_FE_mag", cmap="coolwarm")
plotter.add_axes()

plotter.subplot(1, 0)
plotter.add_text("FOL: Contour of U_FOL_mag", font_size=12)
plotter.add_mesh(fol_contour, scalars="U_FOL_mag", cmap="coolwarm")
plotter.add_axes()

plotter.subplot(1, 1)
plotter.add_text("FOL: Orthogonal Slices", font_size=12)
plotter.add_mesh(fol_slices, scalars="U_FOL_mag", cmap="coolwarm")
plotter.add_axes()

plotter.link_views()
plotter.view_isometric()
plotter.render()
plotter.screenshot(screenshot_path)
plotter.close()

print(f"\n Screenshot saved to: {screenshot_path}")
