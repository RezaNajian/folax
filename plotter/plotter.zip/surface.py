import os
import re
import numpy as np
import pyvista as pv
import matplotlib.pyplot as plt

# ------------------------
# CONFIGURATION
# ------------------------
script_dir = os.path.dirname(os.path.abspath(__file__))
vtk_file = os.path.join(script_dir, "box_3D_fine.vtk")
output_dir = script_dir
os.makedirs(output_dir, exist_ok=True)

# ------------------------
# LOAD & PARSE BEST SAMPLE
# ------------------------
mesh = pv.read(vtk_file)
ufol_keys = [k for k in mesh.point_data if re.match(r"U_FOL_\d+", k)]
ufe_keys = [k for k in mesh.point_data if re.match(r"U_FE_\d+", k)]
common_ids = sorted(set(k.split("_")[-1] for k in ufol_keys) & set(k.split("_")[-1] for k in ufe_keys))

min_error = float("inf")
best_id = None

for i in common_ids:
    u_fol = mesh[f"U_FOL_{i}"]
    u_fe = mesh[f"U_FE_{i}"]
    error = np.linalg.norm(np.linalg.norm(u_fol, axis=1) - np.linalg.norm(u_fe, axis=1))
    if error < min_error:
        min_error = error
        best_id = i

print(f" Best prediction index = {best_id} with L2 error = {min_error:.6f}")

# ------------------------
# FIELD NAMES
# ------------------------
fields = {
    "K_field": f"K_{best_id}",
    "U_FOL": f"U_FOL_{best_id}",
    "U_FE": f"U_FE_{best_id}"
}

# ------------------------
# COMPUTE MAGNITUDES FOR VISUALIZATION
# ------------------------
mesh.point_data["U_FOL_mag"] = np.linalg.norm(mesh[fields["U_FOL"]], axis=1)
mesh.point_data["U_FE_mag"] = np.linalg.norm(mesh[fields["U_FE"]], axis=1)

# ------------------------
# GENERATE CONTOURS AND SLICES
# ------------------------
fe_contour = mesh.contour(scalars="U_FE_mag", isosurfaces=5)
fol_contour = mesh.contour(scalars="U_FOL_mag", isosurfaces=5)

mesh.set_active_scalars("U_FE_mag")
fe_slices = mesh.slice_orthogonal()

mesh.set_active_scalars("U_FOL_mag")
fol_slices = mesh.slice_orthogonal()

# ------------------------
# PLOT 2x2 INTERACTIVE LAYOUT
# ------------------------
plotter = pv.Plotter(shape=(2, 2), window_size=(3200, 2400))

# Top-left: FEM displacement contour
plotter.subplot(0, 0)
plotter.add_text("FEM: Contour of U_FE_mag", font_size=12)
plotter.add_mesh(fe_contour, scalars="U_FE_mag", cmap="coolwarm")
plotter.add_axes()

# Top-right: Orthogonal slices of K(x,y,z)
K_field = fields["K_field"]
if K_field not in mesh.point_data:
    raise KeyError(f"Field '{K_field}' not found in mesh.point_data")

mesh.set_active_scalars(K_field)
k_slices = mesh.slice_orthogonal()

plotter.subplot(0, 1)
plotter.add_text("FEM: Orthogonal Slices of K(x,y,z)", font_size=12)
plotter.add_mesh(k_slices, scalars=K_field, cmap="coolwarm")
plotter.add_axes()

# Bottom-left: FOL displacement contour
plotter.subplot(1, 0)
plotter.add_text("FOL: Contour of U_FOL_mag", font_size=12)
plotter.add_mesh(fol_contour, scalars="U_FOL_mag", cmap="coolwarm")
plotter.add_axes()

# Bottom-right: Absolute Error (|U_FE - U_FOL|)
mesh.point_data["abs_error"] = np.abs(mesh["U_FE_mag"] - mesh["U_FOL_mag"])
mesh.set_active_scalars("abs_error")
error_slices = mesh.slice_orthogonal()

plotter.subplot(1, 1)
plotter.add_text("|U_FE - U_FOL|: Orthogonal Slices", font_size=12)
plotter.add_mesh(error_slices, scalars="abs_error", cmap="coolwarm")
plotter.add_axes()

plotter.link_views()
plotter.view_isometric()
plotter.show()
